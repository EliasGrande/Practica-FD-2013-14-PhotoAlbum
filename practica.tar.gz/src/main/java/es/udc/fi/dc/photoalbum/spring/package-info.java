/**
Contains services interfaces and implementations
 */
package es.udc.fi.dc.photoalbum.spring;

