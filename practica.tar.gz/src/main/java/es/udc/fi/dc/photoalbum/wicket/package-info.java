/**
Contains some components and Wicket settings
 */
package es.udc.fi.dc.photoalbum.wicket;

