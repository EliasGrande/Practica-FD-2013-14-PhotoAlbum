/**
Contains hibernate entities, DAO interfaces and implementations of those DAOs
 */
package es.udc.fi.dc.photoalbum.hibernate;

