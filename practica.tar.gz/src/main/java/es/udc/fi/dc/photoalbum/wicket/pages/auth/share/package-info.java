/**
Contains HTML's and related java's for pages, that can be accessed only when logged in,
 that are related to the share activity
 */
package es.udc.fi.dc.photoalbum.wicket.pages.auth.share;

