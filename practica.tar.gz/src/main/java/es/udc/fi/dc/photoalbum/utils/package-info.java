/**
Contains utilities
 */
package es.udc.fi.dc.photoalbum.utils;

