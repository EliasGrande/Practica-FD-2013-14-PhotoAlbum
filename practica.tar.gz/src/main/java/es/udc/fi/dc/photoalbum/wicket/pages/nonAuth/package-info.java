/**
Contains HTML's and related java's for pages, that can be accessed only when not logged in
 */
package es.udc.fi.dc.photoalbum.wicket.pages.nonAuth;